import React from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

const nav = [
  { path: '/chamber',   label: 'The Chamber',  icon: '⚜️' },
  { path: '/houses',    label: 'Houses',        icon: '🏛️' },
  { path: '/proposals', label: 'Proposals',     icon: '📜' },
  { path: '/duel',      label: 'Grand Duel',    icon: '⚔️' },
];

export default function Sidebar() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();

  return (
    <aside className="sidebar">
      <div className="sidebar-crest">
        <span className="crest-icon">⚜️</span>
        <div className="crest-name">GrandSouk</div>
        <div className="crest-sub">The Auction Chamber</div>
      </div>

      <nav className="sidebar-nav">
        <div className="nav-section-label">Navigation</div>
        {nav.map(n => (
          <div
            key={n.path}
            className={`nav-item ${location.pathname === n.path ? 'active' : ''}`}
            onClick={() => navigate(n.path)}
          >
            <span className="nav-icon">{n.icon}</span>
            {n.label}
          </div>
        ))}
      </nav>

      <div className="sidebar-footer">
        <div className="user-medallion">{user?.name?.[0]?.toUpperCase()}</div>
        <div className="user-info">
          <div className="user-name">{user?.name}</div>
          <div className="user-title">{user?.title || 'Auctioneer'}</div>
        </div>
        <button className="logout-btn" onClick={logout} title="Leave chamber">⇥</button>
      </div>
    </aside>
  );
}
