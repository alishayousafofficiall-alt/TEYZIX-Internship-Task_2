import React, { useEffect, useState } from 'react';
import api from '../utils/api';

const ago = d => {
  const s = Math.floor((Date.now() - new Date(d)) / 1000);
  if (s < 60) return `${s}s ago`;
  if (s < 3600) return `${Math.floor(s/60)}m ago`;
  if (s < 86400) return `${Math.floor(s/3600)}h ago`;
  return `${Math.floor(s/86400)}d ago`;
};

export default function Chamber() {
  const [data, setData] = useState(null);

  useEffect(() => {
    api.get('/chamber').then(r => setData(r.data)).catch(() => {});
  }, []);

  if (!data) return <div style={{ color: 'var(--text3)', padding: 60, textAlign: 'center', fontStyle: 'italic' }}>The chamber stirs…</div>;

  const stats = [
    { label: 'Registered Houses', val: data.totalHouses,       icon: '🏛️', color: 'var(--gold)' },
    { label: 'Active Houses',     val: data.activeHouses,       icon: '⚜️', color: 'var(--gold2)' },
    { label: 'Total Proposals',   val: data.totalProposals,     icon: '📜', color: 'var(--text2)' },
    { label: 'Awaiting Verdict',  val: data.pendingProposals,   icon: '⏳', color: 'var(--amber)' },
    { label: 'Sanctioned',        val: data.sanctionedProposals,icon: '✦',  color: 'var(--gold)' },
    { label: 'Declined',          val: data.declinedProposals,  icon: '✕',  color: '#e87a8a' },
  ];

  return (
    <div>
      <div className="ornament">
        <h1>The Chamber</h1>
        <div className="ornament-line" />
      </div>
      <p className="ornament-sub">An overview of all houses, proposals, and recent decrees</p>

      <div className="stats-grid">
        {stats.map(s => (
          <div className="stat-card" key={s.label}>
            <span className="stat-icon">{s.icon}</span>
            <div className="stat-val" style={{ color: s.color }}>{s.val}</div>
            <div className="stat-label">{s.label}</div>
          </div>
        ))}
      </div>

      <div className="card">
        <h3 style={{ fontFamily: 'Cinzel,serif', fontSize: 13, letterSpacing: '0.12em', color: 'var(--gold-dim)', textTransform: 'uppercase', marginBottom: 18 }}>
          The Grand Ledger — Recent Decrees
        </h3>
        {!data.recentLedger?.length ? (
          <div className="empty">
            <span className="empty-icon">📖</span>
            <h3>The ledger is empty</h3>
            <p>No decrees have been recorded yet</p>
          </div>
        ) : data.recentLedger.map((e, i) => (
          <div className="ledger-entry" key={i}>
            <div className="ledger-seal" />
            <div>
              <div className="ledger-text">
                <strong style={{ color: 'var(--gold2)' }}>{e.scribeName}</strong> — {e.entry}
                {e.entityName && <em style={{ color: 'var(--text3)', marginLeft: 6 }}>"{e.entityName}"</em>}
              </div>
              <div className="ledger-time">{ago(e.createdAt)}</div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
