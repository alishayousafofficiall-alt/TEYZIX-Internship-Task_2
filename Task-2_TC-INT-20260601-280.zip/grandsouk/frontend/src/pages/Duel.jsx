import React, { useEffect, useState } from 'react';
import api from '../utils/api';
import toast from 'react-hot-toast';

export default function Duel() {
  const [proposals, setProposals] = useState([]);
  const [loading, setLoading]     = useState(true);
  const [search, setSearch]       = useState('');

  const fetch = async () => {
    setLoading(true);
    try {
      const p = {};
      if (search) p.scrollTitle = search;
      const { data } = await api.get('/proposals/duel', { params: p });
      setProposals(data);
    } catch { toast.error('Could not open the duel chamber'); }
    finally { setLoading(false); }
  };

  useEffect(() => { fetch(); }, []);

  const withAmount = proposals.filter(p => p.bidAmount != null);
  const minBid     = withAmount.length ? Math.min(...withAmount.map(p => p.bidAmount)) : null;
  const maxBid     = withAmount.length ? Math.max(...withAmount.map(p => p.bidAmount)) : null;
  const avgBid     = withAmount.length ? Math.round(withAmount.reduce((a,p) => a + p.bidAmount, 0) / withAmount.length) : null;

  const fmt = n => n != null ? `${Number(n).toLocaleString()}` : '—';
  const tierColors = { bronze:'#cd7f32', silver:'#c0c0c0', gold:'var(--gold)', platinum:'#b0c4de' };

  return (
    <div>
      <div className="ornament">
        <h1>Grand Duel</h1>
        <div className="ornament-line" />
      </div>
      <p className="ornament-sub">Let the houses compete — the lowest bid claims the crown</p>

      <div className="toolbar" style={{ marginBottom: 24 }}>
        <div className="search-box">
          <span className="search-icon">⚜</span>
          <input placeholder="Filter by scroll title…" value={search} onChange={e => setSearch(e.target.value)} onKeyDown={e => e.key === 'Enter' && fetch()} />
        </div>
        <button className="btn btn-gold" onClick={fetch}>Open the Duel</button>
      </div>

      {loading ? (
        <div style={{ color: 'var(--text3)', padding: 60, textAlign: 'center', fontStyle: 'italic' }}>The houses prepare their bids…</div>
      ) : !proposals.length ? (
        <div className="empty">
          <span className="empty-icon">⚔️</span>
          <h3>No bids entered the arena</h3>
          <p>Only submitted or sanctioned proposals with bid amounts enter the Grand Duel</p>
        </div>
      ) : (
        <>
          {/* Summary banner */}
          {withAmount.length > 1 && (
            <div className="card" style={{ marginBottom: 24, borderColor: 'var(--gold-dim)' }}>
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(150px,1fr))', gap: 20, textAlign: 'center' }}>
                {[
                  { label: 'Victor Bid', val: fmt(minBid), color: 'var(--gold)', icon: '👑' },
                  { label: 'Highest Bid', val: fmt(maxBid), color: '#e87a8a', icon: '⬆' },
                  { label: 'Average Bid', val: fmt(avgBid), color: 'var(--text2)', icon: '⚖' },
                  { label: 'Houses in Duel', val: proposals.length, color: 'var(--gold2)', icon: '⚔' },
                ].map(s => (
                  <div key={s.label}>
                    <div style={{ fontSize: 22, marginBottom: 6 }}>{s.icon}</div>
                    <div style={{ fontFamily: 'Cinzel,serif', fontSize: 22, fontWeight: 700, color: s.color }}>{s.val}</div>
                    <div style={{ fontFamily: 'Inter,sans-serif', fontSize: 10, color: 'var(--text3)', textTransform: 'uppercase', letterSpacing: '0.15em', marginTop: 4 }}>{s.label}</div>
                    {s.label !== 'Houses in Duel' && <div style={{ fontSize: 11, color: 'var(--text3)', marginTop: 2, fontStyle: 'italic' }}>ducats</div>}
                  </div>
                ))}
              </div>
            </div>
          )}

          <div style={{ marginBottom: 14, color: 'var(--text3)', fontSize: 13, fontStyle: 'italic' }}>
            {proposals.length} house{proposals.length > 1 ? 's' : ''} entered — ranked by bid, lowest first
          </div>

          <div className="duel-grid">
            {proposals.map((p, i) => {
              const isVictor = p.bidAmount != null && p.bidAmount === minBid;
              const tier = p.house?.tier || 'bronze';
              return (
                <div key={p._id} className={`duel-card ${isVictor ? 'victor' : ''}`}>
                  {isVictor && <div className="victor-crown">👑 Victor</div>}

                  <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 6 }}>
                    <span style={{ fontSize: 20, opacity: 0.6 }}>#{i+1}</span>
                    <div>
                      <div className="duel-house">{p.house?.estateTitle || '—'}</div>
                      <div style={{ fontSize: 11, color: tierColors[tier], fontFamily: 'Cinzel,serif', letterSpacing: '0.08em' }}>✦ {tier}</div>
                    </div>
                  </div>

                  <div className="duel-title">{p.scrollTitle}</div>
                  <div className="duel-amount">
                    {p.bidAmount != null ? `${Number(p.bidAmount).toLocaleString()}` : 'No bid'}
                    {p.bidAmount != null && <span style={{ fontSize: 14, color: 'var(--text3)', marginLeft: 6 }}>ducats</span>}
                  </div>

                  <div style={{ fontSize: 13, color: 'var(--text3)', fontStyle: 'italic', marginBottom: 14, lineHeight: 1.5 }}>
                    {p.decree?.length > 90 ? p.decree.slice(0, 90) + '…' : p.decree}
                  </div>

                  <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap', alignItems: 'center' }}>
                    <span className={`badge badge-${p.verdict}`}>{p.verdict}</span>
                    {p.sealedOn && (
                      <span style={{ fontSize: 11, color: 'var(--text3)', fontStyle: 'italic' }}>
                        Sealed {new Date(p.sealedOn).toLocaleDateString('en-GB', { day:'numeric', month:'short', year:'numeric' })}
                      </span>
                    )}
                  </div>

                  {p.house?.seal && (
                    <div style={{ marginTop: 12, fontSize: 11, color: 'var(--text3)', borderTop: '1px solid var(--border)', paddingTop: 10, letterSpacing: '0.03em' }}>
                      📮 {p.house.seal}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </>
      )}
    </div>
  );
}
