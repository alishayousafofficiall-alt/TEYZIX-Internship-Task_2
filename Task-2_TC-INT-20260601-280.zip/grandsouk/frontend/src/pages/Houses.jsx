import React, { useEffect, useState, useCallback } from 'react';
import api from '../utils/api';
import toast from 'react-hot-toast';

const empty = { houseName:'', estateTitle:'', seal:'', envoy:'', quarters:'', standing:'active', tier:'bronze', speciality:'' };

export default function Houses() {
  const [houses, setHouses]   = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch]   = useState('');
  const [fStanding, setFS]    = useState('');
  const [fTier, setFT]        = useState('');
  const [modal, setModal]     = useState(false);
  const [form, setForm]       = useState(empty);
  const [editId, setEditId]   = useState(null);
  const [saving, setSaving]   = useState(false);
  const [delId, setDelId]     = useState(null);

  const fetch = useCallback(async () => {
    setLoading(true);
    try {
      const p = {};
      if (search)   p.search  = search;
      if (fStanding) p.standing = fStanding;
      if (fTier)    p.tier    = fTier;
      const { data } = await api.get('/houses', { params: p });
      setHouses(data);
    } catch { toast.error('Failed to summon houses'); }
    finally { setLoading(false); }
  }, [search, fStanding, fTier]);

  useEffect(() => { fetch(); }, [fetch]);

  const openAdd  = () => { setForm(empty); setEditId(null); setModal(true); };
  const openEdit = h => {
    setForm({ houseName: h.houseName, estateTitle: h.estateTitle, seal: h.seal, envoy: h.envoy, quarters: h.quarters, standing: h.standing, tier: h.tier, speciality: h.speciality || '' });
    setEditId(h._id); setModal(true);
  };
  const close = () => { setModal(false); setEditId(null); };
  const handle = e => setForm({ ...form, [e.target.name]: e.target.value });

  const save = async () => {
    if (!form.houseName || !form.estateTitle || !form.seal || !form.envoy || !form.quarters)
      return toast.error('All required fields must be filled');
    setSaving(true);
    try {
      if (editId) { await api.put(`/houses/${editId}`, form); toast.success('House records updated'); }
      else { await api.post('/houses', form); toast.success('House inducted into the registry'); }
      close(); fetch();
    } catch (e) { toast.error(e.response?.data?.message || 'The vault refused'); }
    finally { setSaving(false); }
  };

  const confirmDel = async () => {
    try { await api.delete(`/houses/${delId}`); toast.success('House expelled'); setDelId(null); fetch(); }
    catch { toast.error('Expulsion failed'); }
  };

  const tierMap = { bronze:'tier-bronze', silver:'tier-silver', gold:'tier-gold', platinum:'tier-platinum' };

  return (
    <div>
      <div className="ornament">
        <h1>Houses</h1>
        <div className="ornament-line" />
      </div>
      <p className="ornament-sub">Manage the trading houses registered in the Grand Souk</p>

      <div className="toolbar">
        <div className="search-box">
          <span className="search-icon">⚜</span>
          <input placeholder="Search by name or seal…" value={search} onChange={e => setSearch(e.target.value)} />
        </div>
        <select className="filter-select" value={fStanding} onChange={e => setFS(e.target.value)}>
          <option value="">All Standing</option>
          <option value="active">Active</option>
          <option value="suspended">Suspended</option>
        </select>
        <select className="filter-select" value={fTier} onChange={e => setFT(e.target.value)}>
          <option value="">All Tiers</option>
          <option value="bronze">Bronze</option>
          <option value="silver">Silver</option>
          <option value="gold">Gold</option>
          <option value="platinum">Platinum</option>
        </select>
        <button className="btn btn-gold" onClick={openAdd}>✦ Induct House</button>
      </div>

      <div className="card" style={{ padding: 0 }}>
        <div className="table-wrap">
          {loading ? (
            <div style={{ padding: 50, textAlign: 'center', color: 'var(--text3)', fontStyle: 'italic' }}>Consulting the registry…</div>
          ) : !houses.length ? (
            <div className="empty"><span className="empty-icon">🏛️</span><h3>No houses registered</h3><p>Induct the first trading house to begin</p></div>
          ) : (
            <table>
              <thead>
                <tr><th>House</th><th>Estate</th><th>Seal</th><th>Tier</th><th>Standing</th><th>Speciality</th><th>Decrees</th></tr>
              </thead>
              <tbody>
                {houses.map(h => (
                  <tr key={h._id}>
                    <td>{h.houseName}</td>
                    <td>{h.estateTitle}</td>
                    <td style={{ fontSize: 13 }}>{h.seal}</td>
                    <td><span className={`tier-badge ${tierMap[h.tier]}`}>{h.tier}</span></td>
                    <td><span className={`badge badge-${h.standing}`}>{h.standing}</span></td>
                    <td style={{ fontSize: 13, color: 'var(--text3)', fontStyle: 'italic' }}>{h.speciality || '—'}</td>
                    <td>
                      <div style={{ display: 'flex', gap: 6 }}>
                        <button className="btn btn-outline btn-sm" onClick={() => openEdit(h)}>Edit</button>
                        <button className="btn btn-crimson btn-sm" onClick={() => setDelId(h._id)}>Expel</button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      </div>

      {modal && (
        <div className="modal-overlay" onClick={close}>
          <div className="modal" style={{ maxWidth: 580 }} onClick={e => e.stopPropagation()}>
            <div className="modal-header">
              <h3>{editId ? 'Amend House Records' : 'Induct a New House'}</h3>
              <button className="modal-close" onClick={close}>✕</button>
            </div>
            <div className="modal-body">
              <div className="form-row">
                <div className="form-group">
                  <label className="form-label">House Name *</label>
                  <input className="form-control" name="houseName" value={form.houseName} onChange={handle} placeholder="House of Mercer…" />
                </div>
                <div className="form-group">
                  <label className="form-label">Estate Title *</label>
                  <input className="form-control" name="estateTitle" value={form.estateTitle} onChange={handle} placeholder="Mercer Trading Co." />
                </div>
              </div>
              <div className="form-group">
                <label className="form-label">Seal (Email) *</label>
                <input className="form-control" name="seal" type="email" value={form.seal} onChange={handle} placeholder="envoy@house.com" />
              </div>
              <div className="form-row">
                <div className="form-group">
                  <label className="form-label">Envoy (Contact) *</label>
                  <input className="form-control" name="envoy" value={form.envoy} onChange={handle} placeholder="+92 300 0000000" />
                </div>
                <div className="form-group">
                  <label className="form-label">Tier</label>
                  <select className="form-control" name="tier" value={form.tier} onChange={handle}>
                    <option value="bronze">Bronze</option>
                    <option value="silver">Silver</option>
                    <option value="gold">Gold</option>
                    <option value="platinum">Platinum</option>
                  </select>
                </div>
              </div>
              <div className="form-row">
                <div className="form-group">
                  <label className="form-label">Standing</label>
                  <select className="form-control" name="standing" value={form.standing} onChange={handle}>
                    <option value="active">Active</option>
                    <option value="suspended">Suspended</option>
                  </select>
                </div>
                <div className="form-group">
                  <label className="form-label">Speciality</label>
                  <input className="form-control" name="speciality" value={form.speciality} onChange={handle} placeholder="Silks, Spices, Gems…" />
                </div>
              </div>
              <div className="form-group">
                <label className="form-label">Quarters (Address) *</label>
                <textarea className="form-control" name="quarters" value={form.quarters} onChange={handle} placeholder="Chamber quarter, district, city…" />
              </div>
            </div>
            <div className="modal-footer">
              <button className="btn btn-outline" onClick={close}>Cancel</button>
              <button className="btn btn-gold" onClick={save} disabled={saving}>{saving ? 'Sealing…' : editId ? 'Amend Records' : 'Induct House'}</button>
            </div>
          </div>
        </div>
      )}

      {delId && (
        <div className="modal-overlay" onClick={() => setDelId(null)}>
          <div className="modal" style={{ maxWidth: 380 }} onClick={e => e.stopPropagation()}>
            <div className="modal-header"><h3>Expel House</h3><button className="modal-close" onClick={() => setDelId(null)}>✕</button></div>
            <div className="modal-body"><p style={{ color: 'var(--text2)', fontStyle: 'italic' }}>Are you certain you wish to expel this house from the Grand Souk registry? This decree cannot be undone.</p></div>
            <div className="modal-footer">
              <button className="btn btn-outline" onClick={() => setDelId(null)}>Withdraw</button>
              <button className="btn btn-crimson" onClick={confirmDel}>Issue Decree</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
