import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import api from '../utils/api';
import toast from 'react-hot-toast';

export default function AuthPage() {
  const [isLogin, setIsLogin] = useState(true);
  const [form, setForm] = useState({ name: '', email: '', password: '' });
  const [loading, setLoading] = useState(false);
  const { login } = useAuth();
  const navigate = useNavigate();

  const handle = e => setForm({ ...form, [e.target.name]: e.target.value });

  const submit = async () => {
    if (!form.email || !form.password) return toast.error('Present your credentials');
    if (!isLogin && !form.name) return toast.error('Your name is required');
    setLoading(true);
    try {
      const { data } = await api.post(isLogin ? '/auth/login' : '/auth/register', form);
      login(data);
      toast.success(`Welcome to the chamber, ${data.name}`);
      navigate('/chamber');
    } catch (e) {
      toast.error(e.response?.data?.message || 'The vault refused entry');
    } finally { setLoading(false); }
  };

  return (
    <div className="auth-page">
      <div className="auth-card">
        <div className="auth-logo">
          <span className="auth-crest">⚜️</span>
          <h1>GrandSouk</h1>
          <p>The Auction Chamber</p>
        </div>

        <div className="auth-divider">
          {isLogin ? 'Present Your Seal' : 'Register Your House'}
        </div>

        {!isLogin && (
          <div className="form-group">
            <label className="form-label">Your Name</label>
            <input className="form-control" name="name" placeholder="Lord Ashford…" value={form.name} onChange={handle} />
          </div>
        )}
        <div className="form-group">
          <label className="form-label">Seal (Email)</label>
          <input className="form-control" name="email" type="email" placeholder="seal@grandsouk.com" value={form.email} onChange={handle} />
        </div>
        <div className="form-group">
          <label className="form-label">Passphrase</label>
          <input className="form-control" name="password" type="password" placeholder="••••••••" value={form.password} onChange={handle}
            onKeyDown={e => e.key === 'Enter' && submit()} />
        </div>

        <button className="btn btn-gold" style={{ width: '100%', justifyContent: 'center', marginTop: 8 }}
          onClick={submit} disabled={loading}>
          {loading ? 'Verifying seal…' : isLogin ? 'Enter the Chamber' : 'Register & Enter'}
        </button>

        <div className="auth-footer" style={{ marginTop: 24 }}>
          {isLogin ? 'No house registered? ' : 'Already sealed? '}
          <a onClick={() => setIsLogin(!isLogin)}>{isLogin ? 'Register your house' : 'Enter existing seal'}</a>
        </div>
      </div>
    </div>
  );
}
