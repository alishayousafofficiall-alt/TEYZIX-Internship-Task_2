import React, { useEffect, useState, useCallback } from 'react';
import api from '../utils/api';
import toast from 'react-hot-toast';

const empty = { scrollTitle:'', decree:'', house:'', bidAmount:'', sealedOn:'', verdict:'pending', chamber:'' };
const vm = { pending:'badge-pending', submitted:'badge-submitted', sanctioned:'badge-sanctioned', declined:'badge-declined' };

export default function Proposals() {
  const [proposals, setProposals] = useState([]);
  const [houses, setHouses]       = useState([]);
  const [loading, setLoading]     = useState(true);
  const [search, setSearch]       = useState('');
  const [fVerdict, setFV]         = useState('');
  const [modal, setModal]         = useState(false);
  const [form, setForm]           = useState(empty);
  const [editId, setEditId]       = useState(null);
  const [saving, setSaving]       = useState(false);
  const [delId, setDelId]         = useState(null);
  const [view, setView]           = useState(null);

  const fetch = useCallback(async () => {
    setLoading(true);
    try {
      const p = {};
      if (search)   p.search  = search;
      if (fVerdict) p.verdict = fVerdict;
      const [pr, hr] = await Promise.all([
        api.get('/proposals', { params: p }),
        api.get('/houses'),
      ]);
      setProposals(pr.data); setHouses(hr.data);
    } catch { toast.error('Failed to retrieve scrolls'); }
    finally { setLoading(false); }
  }, [search, fVerdict]);

  useEffect(() => { fetch(); }, [fetch]);

  const openAdd  = () => { setForm(empty); setEditId(null); setModal(true); };
  const openEdit = p => {
    setForm({ scrollTitle: p.scrollTitle, decree: p.decree, house: p.house?._id||'', bidAmount: p.bidAmount||'', sealedOn: p.sealedOn?p.sealedOn.slice(0,10):'', verdict: p.verdict, chamber: p.chamber||'' });
    setEditId(p._id); setModal(true);
  };
  const close  = () => { setModal(false); setEditId(null); };
  const handle = e => setForm({ ...form, [e.target.name]: e.target.value });

  const save = async () => {
    if (!form.scrollTitle || !form.decree || !form.house) return toast.error('Title, decree and house are required');
    setSaving(true);
    try {
      const payload = { ...form, bidAmount: form.bidAmount ? Number(form.bidAmount) : null, sealedOn: form.sealedOn || null };
      if (editId) { await api.put(`/proposals/${editId}`, payload); toast.success('Scroll amended'); }
      else { await api.post('/proposals', payload); toast.success('Proposal scroll issued'); }
      close(); fetch();
    } catch (e) { toast.error(e.response?.data?.message || 'The scribe refused'); }
    finally { setSaving(false); }
  };

  const confirmDel = async () => {
    try { await api.delete(`/proposals/${delId}`); toast.success('Scroll burned'); setDelId(null); fetch(); }
    catch { toast.error('Failed to burn scroll'); }
  };

  const fmt = n => n != null ? `${Number(n).toLocaleString()} Ducats` : '—';

  return (
    <div>
      <div className="ornament">
        <h1>Proposals</h1>
        <div className="ornament-line" />
      </div>
      <p className="ornament-sub">Issue and manage proposal scrolls across all registered houses</p>

      <div className="toolbar">
        <div className="search-box">
          <span className="search-icon">⚜</span>
          <input placeholder="Search scrolls…" value={search} onChange={e => setSearch(e.target.value)} />
        </div>
        <select className="filter-select" value={fVerdict} onChange={e => setFV(e.target.value)}>
          <option value="">All Verdicts</option>
          <option value="pending">Pending</option>
          <option value="submitted">Submitted</option>
          <option value="sanctioned">Sanctioned</option>
          <option value="declined">Declined</option>
        </select>
        <button className="btn btn-gold" onClick={openAdd}>✦ Issue Scroll</button>
      </div>

      <div className="card" style={{ padding: 0 }}>
        <div className="table-wrap">
          {loading ? (
            <div style={{ padding: 50, textAlign: 'center', color: 'var(--text3)', fontStyle: 'italic' }}>Unrolling the scrolls…</div>
          ) : !proposals.length ? (
            <div className="empty"><span className="empty-icon">📜</span><h3>No scrolls issued</h3><p>Issue the first proposal to a trading house</p></div>
          ) : (
            <table>
              <thead>
                <tr><th>Scroll</th><th>House</th><th>Bid (Ducats)</th><th>Verdict</th><th>Sealed On</th><th>Decrees</th></tr>
              </thead>
              <tbody>
                {proposals.map(p => (
                  <tr key={p._id}>
                    <td>{p.scrollTitle}</td>
                    <td>
                      <div style={{ fontSize: 13 }}>{p.house?.estateTitle||'—'}</div>
                      <div style={{ fontSize: 11, color: 'var(--text3)' }}>{p.house?.houseName}</div>
                    </td>
                    <td style={{ color: 'var(--gold)', fontFamily: 'Cinzel,serif', fontWeight: 600 }}>{fmt(p.bidAmount)}</td>
                    <td><span className={`badge ${vm[p.verdict]}`}>{p.verdict}</span></td>
                    <td style={{ fontSize: 13, color: 'var(--text3)', fontStyle: 'italic' }}>
                      {p.sealedOn ? new Date(p.sealedOn).toLocaleDateString('en-GB', { day:'numeric', month:'short', year:'numeric' }) : '—'}
                    </td>
                    <td>
                      <div style={{ display: 'flex', gap: 6 }}>
                        <button className="btn btn-outline btn-sm" onClick={() => setView(p)}>View</button>
                        <button className="btn btn-outline btn-sm" onClick={() => openEdit(p)}>Edit</button>
                        <button className="btn btn-crimson btn-sm" onClick={() => setDelId(p._id)}>Burn</button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      </div>

      {/* Issue/Edit Modal */}
      {modal && (
        <div className="modal-overlay" onClick={close}>
          <div className="modal" style={{ maxWidth: 580 }} onClick={e => e.stopPropagation()}>
            <div className="modal-header">
              <h3>{editId ? 'Amend the Scroll' : 'Issue a Proposal Scroll'}</h3>
              <button className="modal-close" onClick={close}>✕</button>
            </div>
            <div className="modal-body">
              <div className="form-group">
                <label className="form-label">Scroll Title *</label>
                <input className="form-control" name="scrollTitle" value={form.scrollTitle} onChange={handle} placeholder="Supply of Finest Silks…" />
              </div>
              <div className="form-group">
                <label className="form-label">Decree (Description) *</label>
                <textarea className="form-control" name="decree" value={form.decree} onChange={handle} placeholder="Describe the terms of this proposal…" />
              </div>
              <div className="form-row">
                <div className="form-group">
                  <label className="form-label">Assign House *</label>
                  <select className="form-control" name="house" value={form.house} onChange={handle}>
                    <option value="">Select a house…</option>
                    {houses.filter(h => h.standing === 'active').map(h => (
                      <option key={h._id} value={h._id}>{h.estateTitle}</option>
                    ))}
                  </select>
                </div>
                <div className="form-group">
                  <label className="form-label">Verdict</label>
                  <select className="form-control" name="verdict" value={form.verdict} onChange={handle}>
                    <option value="pending">Pending</option>
                    <option value="submitted">Submitted</option>
                    <option value="sanctioned">Sanctioned</option>
                    <option value="declined">Declined</option>
                  </select>
                </div>
              </div>
              <div className="form-row">
                <div className="form-group">
                  <label className="form-label">Bid Amount (Ducats)</label>
                  <input className="form-control" name="bidAmount" type="number" value={form.bidAmount} onChange={handle} placeholder="0" />
                </div>
                <div className="form-group">
                  <label className="form-label">Sealed On (Date)</label>
                  <input className="form-control" name="sealedOn" type="date" value={form.sealedOn} onChange={handle} />
                </div>
              </div>
              <div className="form-group">
                <label className="form-label">Chamber Notes</label>
                <textarea className="form-control" name="chamber" value={form.chamber} onChange={handle} placeholder="Private notes for the chamber…" style={{ minHeight: 60 }} />
              </div>
            </div>
            <div className="modal-footer">
              <button className="btn btn-outline" onClick={close}>Withdraw</button>
              <button className="btn btn-gold" onClick={save} disabled={saving}>{saving ? 'Sealing…' : editId ? 'Amend Scroll' : 'Issue Scroll'}</button>
            </div>
          </div>
        </div>
      )}

      {/* View Modal */}
      {view && (
        <div className="modal-overlay" onClick={() => setView(null)}>
          <div className="modal" style={{ maxWidth: 500 }} onClick={e => e.stopPropagation()}>
            <div className="modal-header">
              <h3>Proposal Scroll</h3>
              <button className="modal-close" onClick={() => setView(null)}>✕</button>
            </div>
            <div className="modal-body" style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
              <div>
                <div style={{ fontSize: 10, color: 'var(--gold-dim)', fontFamily: 'Cinzel,serif', letterSpacing: '0.12em', marginBottom: 5 }}>SCROLL TITLE</div>
                <div style={{ fontSize: 18, fontFamily: 'Cinzel,serif', color: 'var(--text)' }}>{view.scrollTitle}</div>
              </div>
              <div>
                <div style={{ fontSize: 10, color: 'var(--gold-dim)', fontFamily: 'Cinzel,serif', letterSpacing: '0.12em', marginBottom: 5 }}>DECREE</div>
                <div style={{ color: 'var(--text2)', fontStyle: 'italic' }}>{view.decree}</div>
              </div>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 14 }}>
                <div>
                  <div style={{ fontSize: 10, color: 'var(--gold-dim)', fontFamily: 'Cinzel,serif', letterSpacing: '0.12em', marginBottom: 5 }}>HOUSE</div>
                  <div style={{ fontSize: 14 }}>{view.house?.estateTitle||'—'}</div>
                </div>
                <div>
                  <div style={{ fontSize: 10, color: 'var(--gold-dim)', fontFamily: 'Cinzel,serif', letterSpacing: '0.12em', marginBottom: 5 }}>VERDICT</div>
                  <span className={`badge ${vm[view.verdict]}`}>{view.verdict}</span>
                </div>
                <div>
                  <div style={{ fontSize: 10, color: 'var(--gold-dim)', fontFamily: 'Cinzel,serif', letterSpacing: '0.12em', marginBottom: 5 }}>BID</div>
                  <div style={{ fontFamily: 'Cinzel,serif', fontSize: 20, color: 'var(--gold)' }}>{fmt(view.bidAmount)}</div>
                </div>
                <div>
                  <div style={{ fontSize: 10, color: 'var(--gold-dim)', fontFamily: 'Cinzel,serif', letterSpacing: '0.12em', marginBottom: 5 }}>SEALED ON</div>
                  <div style={{ fontSize: 14, color: 'var(--text2)' }}>{view.sealedOn ? new Date(view.sealedOn).toLocaleDateString('en-GB', { day:'numeric', month:'long', year:'numeric' }) : '—'}</div>
                </div>
              </div>
              {view.chamber && (
                <div style={{ padding: '12px 14px', background: 'var(--bg3)', borderRadius: 4, borderLeft: '2px solid var(--gold-dim)' }}>
                  <div style={{ fontSize: 10, color: 'var(--gold-dim)', fontFamily: 'Cinzel,serif', letterSpacing: '0.12em', marginBottom: 5 }}>CHAMBER NOTES</div>
                  <div style={{ fontSize: 13, color: 'var(--text2)', fontStyle: 'italic' }}>{view.chamber}</div>
                </div>
              )}
            </div>
            <div className="modal-footer">
              <button className="btn btn-outline" onClick={() => setView(null)}>Close Scroll</button>
              <button className="btn btn-gold" onClick={() => { setView(null); openEdit(view); }}>Amend</button>
            </div>
          </div>
        </div>
      )}

      {delId && (
        <div className="modal-overlay" onClick={() => setDelId(null)}>
          <div className="modal" style={{ maxWidth: 380 }} onClick={e => e.stopPropagation()}>
            <div className="modal-header"><h3>Burn the Scroll</h3><button className="modal-close" onClick={() => setDelId(null)}>✕</button></div>
            <div className="modal-body"><p style={{ color: 'var(--text2)', fontStyle: 'italic' }}>Once burned, this proposal scroll cannot be recovered. Do you issue this decree?</p></div>
            <div className="modal-footer">
              <button className="btn btn-outline" onClick={() => setDelId(null)}>Withdraw</button>
              <button className="btn btn-crimson" onClick={confirmDel}>Burn the Scroll</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
