import React from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { Toaster } from 'react-hot-toast';
import { AuthProvider, useAuth } from './context/AuthContext';
import Sidebar   from './components/Sidebar';
import AuthPage  from './pages/AuthPage';
import Chamber   from './pages/Chamber';
import Houses    from './pages/Houses';
import Proposals from './pages/Proposals';
import Duel      from './pages/Duel';

function Guard({ children }) {
  const { user, loading } = useAuth();
  if (loading) return (
    <div style={{ minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'var(--gold-dim)', fontFamily: 'Cinzel,serif', letterSpacing: '0.1em' }}>
      The chamber stirs…
    </div>
  );
  return user ? children : <Navigate to="/enter" replace />;
}

function Shell({ children }) {
  return (
    <div className="layout">
      <Sidebar />
      <main className="main">{children}</main>
    </div>
  );
}

function AppRoutes() {
  const { user } = useAuth();
  return (
    <Routes>
      <Route path="/enter" element={user ? <Navigate to="/chamber" replace /> : <AuthPage />} />
      <Route path="/chamber"   element={<Guard><Shell><Chamber /></Shell></Guard>} />
      <Route path="/houses"    element={<Guard><Shell><Houses /></Shell></Guard>} />
      <Route path="/proposals" element={<Guard><Shell><Proposals /></Shell></Guard>} />
      <Route path="/duel"      element={<Guard><Shell><Duel /></Shell></Guard>} />
      <Route path="*" element={<Navigate to="/chamber" replace />} />
    </Routes>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <BrowserRouter>
        <AppRoutes />
        <Toaster
          position="top-right"
          toastOptions={{
            style: {
              background: '#16141f',
              border: '1px solid #3d3650',
              color: '#f5f0e8',
              fontFamily: 'EB Garamond, Georgia, serif',
              fontSize: '15px',
            },
            success: { iconTheme: { primary: '#d4af37', secondary: '#16141f' } },
            error:   { iconTheme: { primary: '#9b2335', secondary: '#16141f' } },
          }}
        />
      </BrowserRouter>
    </AuthProvider>
  );
}
