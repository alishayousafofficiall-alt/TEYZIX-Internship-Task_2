import React, { createContext, useContext, useState, useEffect } from 'react';
import axios from 'axios';

const Ctx = createContext();

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const s = localStorage.getItem('gsUser');
    if (s) {
      const u = JSON.parse(s);
      setUser(u);
      axios.defaults.headers.common['Authorization'] = `Bearer ${u.token}`;
    }
    setLoading(false);
  }, []);

  const login = (u) => {
    setUser(u);
    localStorage.setItem('gsUser', JSON.stringify(u));
    axios.defaults.headers.common['Authorization'] = `Bearer ${u.token}`;
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem('gsUser');
    delete axios.defaults.headers.common['Authorization'];
  };

  return <Ctx.Provider value={{ user, login, logout, loading }}>{children}</Ctx.Provider>;
};

export const useAuth = () => useContext(Ctx);
