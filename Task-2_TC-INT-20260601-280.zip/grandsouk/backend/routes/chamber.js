const express  = require('express');
const router   = express.Router();
const House    = require('../models/House');
const Proposal = require('../models/Proposal');
const Ledger   = require('../models/Ledger');
const { protect } = require('../middleware/auth');

router.get('/', protect, async (req, res) => {
  try {
    const [
      totalHouses, activeHouses,
      totalProposals, pendingProposals,
      sanctionedProposals, declinedProposals,
      recentLedger,
    ] = await Promise.all([
      House.countDocuments(),
      House.countDocuments({ standing: 'active' }),
      Proposal.countDocuments(),
      Proposal.countDocuments({ verdict: 'pending' }),
      Proposal.countDocuments({ verdict: 'sanctioned' }),
      Proposal.countDocuments({ verdict: 'declined' }),
      Ledger.find().sort({ createdAt: -1 }).limit(10),
    ]);
    res.json({ totalHouses, activeHouses, totalProposals, pendingProposals, sanctionedProposals, declinedProposals, recentLedger });
  } catch (e) { res.status(500).json({ message: e.message }); }
});

module.exports = router;
