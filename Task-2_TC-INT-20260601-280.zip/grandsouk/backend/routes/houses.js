const express = require('express');
const router  = express.Router();
const House   = require('../models/House');
const Ledger  = require('../models/Ledger');
const { protect } = require('../middleware/auth');

const log = async (entry, doc, user) => {
  try { await Ledger.create({ entry, entity: 'house', entityId: doc._id, entityName: doc.estateTitle, scribe: user._id, scribeName: user.name }); } catch {}
};

router.get('/', protect, async (req, res) => {
  try {
    const { search, standing, tier } = req.query;
    const q = {};
    if (search) q.$or = [
      { houseName: { $regex: search, $options: 'i' } },
      { estateTitle: { $regex: search, $options: 'i' } },
      { seal: { $regex: search, $options: 'i' } },
    ];
    if (standing) q.standing = standing;
    if (tier) q.tier = tier;
    res.json(await House.find(q).sort({ createdAt: -1 }));
  } catch (e) { res.status(500).json({ message: e.message }); }
});

router.get('/:id', protect, async (req, res) => {
  try {
    const h = await House.findById(req.params.id);
    if (!h) return res.status(404).json({ message: 'House not found' });
    res.json(h);
  } catch (e) { res.status(500).json({ message: e.message }); }
});

router.post('/', protect, async (req, res) => {
  try {
    const { houseName, estateTitle, seal, envoy, quarters } = req.body;
    if (!houseName || !estateTitle || !seal || !envoy || !quarters)
      return res.status(400).json({ message: 'All fields required' });
    if (await House.findOne({ seal }))
      return res.status(400).json({ message: 'A house with this seal already exists' });
    const h = await House.create({ ...req.body, createdBy: req.user._id });
    await log('Inducted new house', h, req.user);
    res.status(201).json(h);
  } catch (e) { res.status(500).json({ message: e.message }); }
});

router.put('/:id', protect, async (req, res) => {
  try {
    const h = await House.findByIdAndUpdate(req.params.id, req.body, { new: true, runValidators: true });
    if (!h) return res.status(404).json({ message: 'House not found' });
    await log('Updated house records', h, req.user);
    res.json(h);
  } catch (e) { res.status(500).json({ message: e.message }); }
});

router.delete('/:id', protect, async (req, res) => {
  try {
    const h = await House.findByIdAndDelete(req.params.id);
    if (!h) return res.status(404).json({ message: 'House not found' });
    await log('Expelled house from registry', h, req.user);
    res.json({ message: 'House expelled' });
  } catch (e) { res.status(500).json({ message: e.message }); }
});

module.exports = router;
