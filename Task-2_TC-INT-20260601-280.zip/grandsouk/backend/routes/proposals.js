const express  = require('express');
const router   = express.Router();
const Proposal = require('../models/Proposal');
const Ledger   = require('../models/Ledger');
const { protect } = require('../middleware/auth');

const log = async (entry, doc, user) => {
  try { await Ledger.create({ entry, entity: 'proposal', entityId: doc._id, entityName: doc.scrollTitle, scribe: user._id, scribeName: user.name }); } catch {}
};

router.get('/', protect, async (req, res) => {
  try {
    const { verdict, house, search } = req.query;
    const q = {};
    if (verdict) q.verdict = verdict;
    if (house)   q.house   = house;
    if (search)  q.scrollTitle = { $regex: search, $options: 'i' };
    const proposals = await Proposal.find(q)
      .populate('house', 'houseName estateTitle seal tier')
      .sort({ createdAt: -1 });
    res.json(proposals);
  } catch (e) { res.status(500).json({ message: e.message }); }
});

router.get('/duel', protect, async (req, res) => {
  try {
    const { scrollTitle } = req.query;
    const q = { verdict: { $in: ['submitted','sanctioned'] } };
    if (scrollTitle) q.scrollTitle = { $regex: scrollTitle, $options: 'i' };
    const proposals = await Proposal.find(q)
      .populate('house', 'houseName estateTitle seal tier')
      .sort({ bidAmount: 1 });
    res.json(proposals);
  } catch (e) { res.status(500).json({ message: e.message }); }
});

router.get('/:id', protect, async (req, res) => {
  try {
    const p = await Proposal.findById(req.params.id).populate('house');
    if (!p) return res.status(404).json({ message: 'Proposal not found' });
    res.json(p);
  } catch (e) { res.status(500).json({ message: e.message }); }
});

router.post('/', protect, async (req, res) => {
  try {
    const { scrollTitle, decree, house } = req.body;
    if (!scrollTitle || !decree || !house)
      return res.status(400).json({ message: 'Title, decree and house required' });
    const p = await Proposal.create({ ...req.body, createdBy: req.user._id });
    const pop = await p.populate('house', 'houseName estateTitle seal tier');
    await log('Issued new proposal scroll', p, req.user);
    res.status(201).json(pop);
  } catch (e) { res.status(500).json({ message: e.message }); }
});

router.put('/:id', protect, async (req, res) => {
  try {
    const p = await Proposal.findByIdAndUpdate(req.params.id, req.body, { new: true, runValidators: true })
      .populate('house', 'houseName estateTitle seal tier');
    if (!p) return res.status(404).json({ message: 'Proposal not found' });
    await log(`Verdict updated to "${p.verdict}"`, p, req.user);
    res.json(p);
  } catch (e) { res.status(500).json({ message: e.message }); }
});

router.delete('/:id', protect, async (req, res) => {
  try {
    const p = await Proposal.findByIdAndDelete(req.params.id);
    if (!p) return res.status(404).json({ message: 'Proposal not found' });
    await log('Proposal scroll burned', p, req.user);
    res.json({ message: 'Scroll burned' });
  } catch (e) { res.status(500).json({ message: e.message }); }
});

module.exports = router;
