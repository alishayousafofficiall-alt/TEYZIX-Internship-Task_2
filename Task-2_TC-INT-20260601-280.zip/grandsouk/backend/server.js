const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
require('dotenv').config();

const app = express();
app.use(cors());
app.use(express.json());

app.use('/api/auth',      require('./routes/auth'));
app.use('/api/houses',    require('./routes/houses'));
app.use('/api/proposals', require('./routes/proposals'));
app.use('/api/chamber',   require('./routes/chamber'));

app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).json({ message: 'Internal server error' });
});

const PORT     = process.env.PORT     || 5000;
const MONGO_URI = process.env.MONGO_URI || 'mongodb://localhost:27017/grandsouk';

mongoose.connect(MONGO_URI)
  .then(() => {
    console.log('✦ GrandSouk vault connected');
    app.listen(PORT, () => console.log(`✦ Chamber open on port ${PORT}`));
  })
  .catch(err => console.error('Vault error:', err));
