const mongoose = require('mongoose');

// "Proposal" = a quotation/bid submitted to the Grand Souk chamber
const proposalSchema = new mongoose.Schema({
  scrollTitle:  { type: String, required: true, trim: true },   // quotation title
  decree:       { type: String, required: true },                // description
  house:        { type: mongoose.Schema.Types.ObjectId, ref: 'House', required: true },
  bidAmount:    { type: Number, default: null },                 // quotation amount
  sealedOn:     { type: Date,   default: null },                 // submission date
  verdict:      {                                                 // status
    type: String,
    enum: ['pending','submitted','sanctioned','declined'],
    default: 'pending'
  },
  chamber:      { type: String, default: '' },                   // notes
  createdBy:    { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
}, { timestamps: true });

module.exports = mongoose.model('Proposal', proposalSchema);
