const mongoose = require('mongoose');

// "House" = a vendor trading house in the Grand Souk
const houseSchema = new mongoose.Schema({
  houseName:    { type: String, required: true, trim: true },   // vendor name
  estateTitle:  { type: String, required: true, trim: true },   // company name
  seal:         { type: String, required: true, unique: true },  // email (their "seal")
  envoy:        { type: String, required: true },                // contact number
  quarters:     { type: String, required: true },                // business address
  standing:     { type: String, enum: ['active','suspended'], default: 'active' },
  tier:         { type: String, enum: ['bronze','silver','gold','platinum'], default: 'bronze' },
  speciality:   { type: String, default: '' },
  createdBy:    { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
}, { timestamps: true });

module.exports = mongoose.model('House', houseSchema);
