const mongoose = require('mongoose');

const ledgerSchema = new mongoose.Schema({
  entry:       { type: String, required: true },
  entity:      { type: String, enum: ['house','proposal','user'] },
  entityId:    { type: mongoose.Schema.Types.ObjectId },
  entityName:  { type: String },
  scribe:      { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  scribeName:  { type: String },
}, { timestamps: true });

module.exports = mongoose.model('Ledger', ledgerSchema);
